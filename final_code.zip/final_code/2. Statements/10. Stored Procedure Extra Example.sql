--Example of using Stored Procedure for a SQL Statement
--Create Stored Procedure
CREATE OR REPLACE PROCEDURE totalByCompany(date1 in date, date2 in date, c1 in out SYS_REFCURSOR)
IS
BEGIN
OPEN c1 FOR
select shipcompany as "Company", count(*) as "Total"
from ship s
inner join ship_manifest sm on s.shipid = sm.shipid
inner join dock_manifest dm on sm.manifestid = dm.manifestid
where dm.arrivaltime BETWEEN TO_DATE(date1) AND TO_DATE(date2)
group by s.shipcompany
order by count(*) asc;
END;

--Declare Variable Cursor
VARIABLE cursor_output refcursor;
--Execute Stored Procedure
execute totalByCompany(TO_DATE('2020/01/01 00:00', 'yyyy/mm/dd hh24:mi'), TO_DATE('2020/01/31 23:59', 'yyyy/mm/dd hh24:mi'), :cursor_output);
--Print output
print cursor_output;