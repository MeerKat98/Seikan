--Search for Cargo Container/s Code starting with specific letter/character
select containerid as ID, containercode as "Code"
from cargo_container
where containercode like 'D%'
order by containercode asc;