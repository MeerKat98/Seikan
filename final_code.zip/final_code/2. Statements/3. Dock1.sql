--Search for Docking Station/s Number starting with specific letter
--Note the format of the Docking Number is ^^## where ^ is a letter and # is a number
select * from docking_station
where dockno like 'X%';