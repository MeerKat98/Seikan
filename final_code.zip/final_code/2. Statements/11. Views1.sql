--Output is which Ships leave our "Seikan - Nebula Trading Port" without any Cargo in a specific time frame, their intended destinations and where they were docked.
create or replace view NoCargo_Outbound as
SELECT s.shipname as "Ship", sl.locationname as "Destination", to_char(dm.departuretime,'dd-Mon-yyyy hh24:mi') as "Departure Time", ds.dockno as "Dock Number", sm.manifestid as "Manifest ID"
FROM spaceport_location sl
inner join ship_manifest sm on sl.locationid = sm.locationid_destination
inner join dock_manifest dm on sm.manifestid = dm.manifestid
inner join ship s on sm.shipid = s.shipid
inner join docking_station ds on dm.dockingid = ds.dockingid
where sm.locationid_destination > 1
and sm.locationid_origin = 1
and dm.departuretime BETWEEN TO_DATE('2020/01/01 00:00', 'yyyy/mm/dd hh24:mi') AND TO_DATE('2020/01/01 23:59', 'yyyy/mm/dd hh24:mi')
and sm.manifestid in(
select sm.manifestid from ship_manifest sm
LEFT JOIN manifest_container mc ON sm.manifestid = mc.manifestid
WHERE mc.manifestid IS NULL)
order by sm.manifestid asc;

select * from NoCargo_Outbound;