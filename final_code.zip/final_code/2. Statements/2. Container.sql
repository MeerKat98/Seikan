--Search for Cargo Container/s Code containing specific string of letters or characters
select containerid as "ID", containercode as "Code"
from cargo_container where containercode like '%AD3%'
order by containercode asc;