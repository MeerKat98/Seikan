--Search for a Ship Name belonging to a specific Shipping Company
select shipid as "ID", shipname as "Name", shipcompany as "Comapny" from ship
where shipname like '%IAV%' and shipcompany like '%Ever%';