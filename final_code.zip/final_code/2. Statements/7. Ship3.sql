--Search for all Shipping Company Names
select shipcompany as "Comapny" from ship
group by shipcompany
order by shipcompany asc;