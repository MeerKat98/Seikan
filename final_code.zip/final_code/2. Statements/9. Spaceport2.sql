--Search for Spaceport Location/s containing a specific string of characters
select locationid as "ID", locationname as "Location Name"
from spaceport_location
where locationname like '%port%'
order by locationname asc;