--Search for a Ship Name
select * from ship
where shipname like '%Buzz%';