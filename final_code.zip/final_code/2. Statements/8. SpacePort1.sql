--Search for Spaceport Location/s starting with specific string of characters
select locationid as "ID", locationname as "Location Name"
from spaceport_location
where locationname like 'Sei%'
order by locationname asc;