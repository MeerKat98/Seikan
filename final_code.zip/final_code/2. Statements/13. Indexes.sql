/*
Index will be created on the central table in the database namely SHIP_MANIFEST
Columns used are manifestid, locationid_origin and locationid_destination this is because mpst queries are
based on where the ships are coming from and going to.
If index already created drop it by
DROP INDEX ship_manifest_i
*/
create index ship_manifest_i on ship_manifest (manifestid, locationid_origin, locationid_destination);
