import cx_Oracle
from stopwatch import Stopwatch

con = cx_Oracle.connect('system/cmpg311@127.0.0.1/xe')
cur = con.cursor()
stopwatch = Stopwatch()
total = 0.0
numlines = 0

filepath = "1_Ships.txt"
print('\nStarting insert Ships')
with open(filepath) as fp:
    lines = fp.read().splitlines()
for line in lines:
	cur.execute(str(line))
	numlines += 1
stopwatch.stop()
print(f'Completed inserting {filepath} in {str(stopwatch)}\n')
total += stopwatch.duration

filepath = "2_DockingStations.txt"
print('Starting insert Docking Stations')
stopwatch.reset()
stopwatch.start()
with open(filepath) as fp:
    lines = fp.read().splitlines()
for line in lines:
	cur.execute(str(line))
	numlines += 1
stopwatch.stop()
print(f'Completed inserting {filepath} in {str(stopwatch)}\n')
total += stopwatch.duration

filepath = "3_CargoContainers.txt"
print('Starting insert Cargo Containers')
stopwatch.reset()
stopwatch.start()
with open(filepath) as fp:
    lines = fp.read().splitlines()
for line in lines:
	cur.execute(str(line))
	numlines += 1
stopwatch.stop()
print(f'Completed inserting {filepath} in {str(stopwatch)}\n')
total += stopwatch.duration

filepath = "4_SpaceportLocations.txt"
print('Starting insert Spaceport Locations')
stopwatch.reset()
stopwatch.start()
with open(filepath) as fp:
    lines = fp.read().splitlines()
for line in lines:
	cur.execute(str(line))
	numlines += 1
stopwatch.stop()
print(f'Completed inserting {filepath} in {str(stopwatch)}\n')
total += stopwatch.duration

filepath = "5_ShipManifests.txt"
print('Starting insert Ship Manifests')
stopwatch.reset()
stopwatch.start()
with open(filepath) as fp:
    lines = fp.read().splitlines()
for line in lines:
	cur.execute(str(line))
	numlines += 1
stopwatch.stop()
print(f'Completed inserting {filepath} in {str(stopwatch)}\n')
total += stopwatch.duration

filepath = "6_DockManifests_2016.txt"
print('Starting insert Dock Manifests')
stopwatch.reset()
stopwatch.start()
with open(filepath) as fp:
    lines = fp.read().splitlines()
for line in lines:
	cur.execute(str(line))
	numlines += 1
stopwatch.stop()
print(f'Completed inserting {filepath} in {str(stopwatch)}\n')
total += stopwatch.duration

filepath = "6_DockManifests_2017.txt"
print('Starting insert Dock Manifests cont.')
stopwatch.reset()
stopwatch.start()
with open(filepath) as fp:
    lines = fp.read().splitlines()
for line in lines:
	cur.execute(str(line))
	numlines += 1
stopwatch.stop()
print(f'Completed inserting {filepath} in {str(stopwatch)}\n')
total += stopwatch.duration

filepath = "6_DockManifests_2018.txt"
print('Starting insert Dock Manifests cont.')
stopwatch.reset()
stopwatch.start()
with open(filepath) as fp:
    lines = fp.read().splitlines()
for line in lines:
	cur.execute(str(line))
	numlines += 1
stopwatch.stop()
print(f'Completed inserting {filepath} in {str(stopwatch)}\n')
total += stopwatch.duration

filepath = "6_DockManifests_2019.txt"
print('Starting insert Dock Manifests cont.')
stopwatch.reset()
stopwatch.start()
with open(filepath) as fp:
    lines = fp.read().splitlines()
for line in lines:
	cur.execute(str(line))
	numlines += 1
stopwatch.stop()
print(f'Completed inserting {filepath} in {str(stopwatch)}\n')
total += stopwatch.duration

filepath = "6_DockManifests_2020.txt"
print('Starting insert Dock Manifests cont.')
stopwatch.reset()
stopwatch.start()
with open(filepath) as fp:
    lines = fp.read().splitlines()
for line in lines:
	cur.execute(str(line))
	numlines += 1
stopwatch.stop()
print(f'Completed inserting {filepath} in {str(stopwatch)}\n')
total += stopwatch.duration

filepath = "6_DockManifests_20162020NoCargo.txt"
print('Starting insert Dock Manifests cont.')
stopwatch.reset()
stopwatch.start()
with open(filepath) as fp:
    lines = fp.read().splitlines()
for line in lines:
	cur.execute(str(line))
	numlines += 1
stopwatch.stop()
print(f'Completed inserting {filepath} in {str(stopwatch)}\n')
total += stopwatch.duration

filepath = "7_ManifestContainers1of5.txt"
print('Starting insert Manifest Containers')
stopwatch.reset()
stopwatch.start()
with open(filepath) as fp:
    lines = fp.read().splitlines()
for line in lines:
	cur.execute(str(line))
	numlines += 1
stopwatch.stop()
print(f'Completed inserting {filepath} in {str(stopwatch)}\n')
total += stopwatch.duration

filepath = "7_ManifestContainers2of5.txt"
print('Starting insert Manifest Containers cont.')
stopwatch.reset()
stopwatch.start()
with open(filepath) as fp:
    lines = fp.read().splitlines()
for line in lines:
	cur.execute(str(line))
	numlines += 1
stopwatch.stop()
print(f'Completed inserting {filepath} in {str(stopwatch)}\n')
total += stopwatch.duration

filepath = "7_ManifestContainers3of5.txt"
print('Starting insert Manifest Containers cont.')
stopwatch.reset()
stopwatch.start()
with open(filepath) as fp:
    lines = fp.read().splitlines()
for line in lines:
	cur.execute(str(line))
	numlines += 1
stopwatch.stop()
print(f'Completed inserting {filepath} in {str(stopwatch)}\n')
total += stopwatch.duration

filepath = "7_ManifestContainers4of5.txt"
print('Starting to insert into Manifest Containers cont.')
stopwatch.reset()
stopwatch.start()
with open(filepath) as fp:
    lines = fp.read().splitlines()
for line in lines:
	cur.execute(str(line))
	numlines += 1
stopwatch.stop()
print(f'Completed inserting {filepath} in {str(stopwatch)}\n')
total += stopwatch.duration

filepath = "7_ManifestContainers5of5.txt"
print('Starting insert Manifest_Containers cont.')
stopwatch.reset()
stopwatch.start()
with open(filepath) as fp:
    lines = fp.read().splitlines()
for line in lines:
	cur.execute(str(line))
	numlines += 1
stopwatch.stop()
print(f'Completed inserting {filepath} in {str(stopwatch)}\n')
con.close()
total += stopwatch.duration
total = total/60
roundTotal = round(total,2)
print(f'Completed data loading in {total} minutes\nTotal enteries inserted are {numlines}')
pass