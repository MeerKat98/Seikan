===========================================================================================================================================================================
PLEASE NOTE!! NB! NB!
This folder contains text files for loading data using Python
For loading with Oracle SQL Developer GUI go to loadData_Semicolon folder
===========================================================================================================================================================================
CHANGES TO DATA
===========================================================================================================================================================================
100 -> 200 Docking Stations
101 -> 300 Locations
500 -> 700 Ships
5,000 -> 10,000 Containers
1,000 -> 110,000 Ship Manifests
1,000 -> 110,000 Dock Manifests
5,000 -> 1,000,000 Container Manifests

5 years worth of data now
insert data in the order that they appear e.g. '1_Ships' then '2_DockingStations' etc...
===========================================================================================================================================================================

===========================================================================================================================================================================

HOW TO GET PYTHON WORKING WITH ORACLE AND USE THE LOAD.PY FILE

===========================================================================================================================================================================

1) Make sure tnsnames.ora file is in the following directory $oracleHOME$/network/admin. Where $oracleHOME$ is root directory of where oracle is installed
and not SQL Developer. The file has been added to zip folder as well
2) Make sure connection string in line 4 of load.py matches your own db. Change cmpg311 to your own password for db.
3) Make sure python 64-bit is installed
4) Download oracle instant client and unzip. Set path of the extracted folder in the environment variables.
5) pip install cx_Oracle
6) pip install stopwatch.py
7) Open IDLE 64-bit and run the load.py file.

Good Hunting! xD :D