==========================================================================================
==========================================================================================
PLEASE NOTE!! NB! NB!
This folder contains text files for loading data using the SQL Developer GUI
For loading with python go to loadData_Python folder
==========================================================================================
==========================================================================================
Changes To Data
100 -> 200 Docking Stations
101 -> 300 Locations
500 -> 700 Ships
5,000 -> 10,000 Containers
1,000 -> 110,000 Ship Manifests
1,000 -> 110,000 Dock Manifests
5,000 -> 1,000,000 Container Manifests

5 years worth of data now
insert data in the order that they appear e.g. '1_Ships' then '2_DockingStations' etc...
==========================================================================================
